#!/bin/sh
python3.6 -m pip install --target . pyclustering